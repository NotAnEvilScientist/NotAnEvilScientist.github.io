var Lang = "default";    // VALUE<string> = default, en, fr, nl, ru, cz, it, sp, de, zh, he, pl, pt, tr
var TwentyFour = "auto"; // VALUE<string/bool/bool> = auto, true, false
var Nth = "auto";        // VALUE<string/bool/bool> = auto, true, false
var PadZero = "auto";    // VALUE<string/bool/bool> = auto, true, false
